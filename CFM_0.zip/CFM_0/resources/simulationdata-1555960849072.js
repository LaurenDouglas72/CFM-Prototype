function initData() {
  jimData.variables["Test Data 2"] = "";
  jimData.variables["footTraffic2Clicked"] = "0";
  jimData.variables["yearClicked"] = "0";
  jimData.variables["dayClicked"] = "0";
  jimData.variables["EditJanuary"] = "";
  jimData.variables["overallClicked"] = "1";
  jimData.variables["weatherCLicked"] = "0";
  jimData.variables["appleButterClicked"] = "0";
  jimData.variables["strawberryClicked"] = "0";
  jimData.variables["footTrafficClicked"] = "0";
  jimData.variables["EditFebruary"] = "";
  jimData.variables["peanutButterClicked"] = "0";
  jimData.variables["raspberryClicked"] = "0";
  jimData.variables["monthClicked"] = "0";
  jimData.datamasters["BlankData"] = [
    {
      "id": 1,
      "datamaster": "BlankData",
      "userdata": {
        "Product": "Ex. Rye",
        "Category": "Ex. Bread",
        "Price": "Ex. $9.99",
        "Date Sold": "Ex. 04/03/2018",
        "Market": "Ex. Ponce City"
      }
    }
  ];

  jimData.datamasters["FebruaryData"] = [
    {
      "id": 1,
      "datamaster": "FebruaryData",
      "userdata": {
        "Product": "Strawberry Jam",
        "Category": "Jam",
        "Price": "$8.00",
        "Date Sold": "02/09/2019",
        "Market": "Grant Park"
      }
    },
    {
      "id": 2,
      "datamaster": "FebruaryData",
      "userdata": {
        "Product": "Raspberry Jam",
        "Category": "Jam",
        "Price": "$8.00",
        "Date Sold": "02/09/2019",
        "Market": "Grant Park"
      }
    },
    {
      "id": 3,
      "datamaster": "FebruaryData",
      "userdata": {
        "Product": "Peanut Butter",
        "Category": "PB",
        "Price": "$7.00",
        "Date Sold": "02/09/2019",
        "Market": "Grant Park"
      }
    },
    {
      "id": 4,
      "datamaster": "FebruaryData",
      "userdata": {
        "Product": "Strawberry Jam",
        "Category": "Jam",
        "Price": "$8.00",
        "Date Sold": "02/09/2019",
        "Market": "Grant Park"
      }
    },
    {
      "id": 5,
      "datamaster": "FebruaryData",
      "userdata": {
        "Product": "Strawberry Jam",
        "Category": "Jam",
        "Price": "$8.00",
        "Date Sold": "02/09/2019",
        "Market": "Grant Park"
      }
    },
    {
      "id": 6,
      "datamaster": "FebruaryData",
      "userdata": {
        "Product": "Strawberry Jam",
        "Category": "Jam",
        "Price": "$8.00",
        "Date Sold": "02/09/2019",
        "Market": "Grant Park"
      }
    },
    {
      "id": 7,
      "datamaster": "FebruaryData",
      "userdata": {
        "Product": "Raspberry Jam",
        "Category": "Jam",
        "Price": "$8.00",
        "Date Sold": "02/09/2019",
        "Market": "Grant Park"
      }
    },
    {
      "id": 8,
      "datamaster": "FebruaryData",
      "userdata": {
        "Product": "Raspberry Jam",
        "Category": "Jam",
        "Price": "$8.00",
        "Date Sold": "02/09/2019",
        "Market": "Grant Park"
      }
    },
    {
      "id": 9,
      "datamaster": "FebruaryData",
      "userdata": {
        "Product": "Peanut Butter",
        "Category": "PB",
        "Price": "$7.00",
        "Date Sold": "02/09/2019",
        "Market": "Grant Park"
      }
    },
    {
      "id": 10,
      "datamaster": "FebruaryData",
      "userdata": {
        "Product": "Peanut Butter",
        "Category": "PB",
        "Price": "$7.00",
        "Date Sold": "02/09/2019",
        "Market": "Grant Park"
      }
    },
    {
      "id": 11,
      "datamaster": "FebruaryData",
      "userdata": {
        "Product": "Peanut Butter",
        "Category": "PB",
        "Price": "$7.00",
        "Date Sold": "02/09/2019",
        "Market": "Grant Park"
      }
    }
  ];
  jimData.datamasters["FebruaryData"].category = {
    "Market": ["Grant Park","Ponce City"]
  };

  jimData.datamasters["Blank Fake Data"] = [
    {
      "id": 1,
      "datamaster": "Blank Fake Data",
      "userdata": {
        "Product": "sample text",
        "Description": "sample text",
        "Category": "",
        "Price": "sample text",
        "Enabled": "",
        "Current Quantity": "sample text",
        "New Quantity": "sample text"
      }
    },
    {
      "id": 2,
      "datamaster": "Blank Fake Data",
      "userdata": {
        "Product": "sample text",
        "Description": "sample text",
        "Category": "",
        "Price": "sample text",
        "Enabled": "",
        "Current Quantity": "sample text",
        "New Quantity": "sample text"
      }
    },
    {
      "id": 3,
      "datamaster": "Blank Fake Data",
      "userdata": {
        "Product": "sample text",
        "Description": "sample text",
        "Category": "",
        "Price": "sample text",
        "Enabled": "",
        "Current Quantity": "sample text",
        "New Quantity": "sample text"
      }
    },
    {
      "id": 4,
      "datamaster": "Blank Fake Data",
      "userdata": {
        "Product": "sample text",
        "Description": "sample text",
        "Category": "",
        "Price": "sample text",
        "Enabled": "",
        "Current Quantity": "sample text",
        "New Quantity": "sample text"
      }
    },
    {
      "id": 5,
      "datamaster": "Blank Fake Data",
      "userdata": {
        "Product": "sample text",
        "Description": "sample text",
        "Category": "",
        "Price": "sample text",
        "Enabled": "",
        "Current Quantity": "sample text",
        "New Quantity": "sample text"
      }
    },
    {
      "id": 6,
      "datamaster": "Blank Fake Data",
      "userdata": {
        "Product": "sample text",
        "Description": "sample text",
        "Category": "",
        "Price": "sample text",
        "Enabled": "",
        "Current Quantity": "sample text",
        "New Quantity": "sample text"
      }
    }
  ];
  jimData.datamasters["Blank Fake Data"].category = {
    "Category": ["Jam","Jelly"]
  };

  jimData.datamasters["Upload_Data"] = [
    {
      "id": 1,
      "datamaster": "Upload_Data",
      "userdata": {
        "Data File": "./resources/jim/images/common/crossimage.png"
      }
    },
    {
      "id": 2,
      "datamaster": "Upload_Data",
      "userdata": {
        "Data File": "./resources/jim/images/common/crossimage.png"
      }
    },
    {
      "id": 3,
      "datamaster": "Upload_Data",
      "userdata": {
        "Data File": "./resources/jim/images/common/crossimage.png"
      }
    },
    {
      "id": 4,
      "datamaster": "Upload_Data",
      "userdata": {
        "Data File": "./resources/jim/images/common/crossimage.png"
      }
    },
    {
      "id": 5,
      "datamaster": "Upload_Data",
      "userdata": {
        "Data File": "./resources/jim/images/common/crossimage.png"
      }
    },
    {
      "id": 6,
      "datamaster": "Upload_Data",
      "userdata": {
        "Data File": "./resources/jim/images/common/crossimage.png"
      }
    }
  ];

  jimData.datamasters["Test Data"] = [
    {
      "id": 1,
      "datamaster": "Test Data",
      "userdata": {
        "Product": "Strawberry Jam",
        "Description": "Strawberry",
        "Category": "",
        "SKU": "10",
        "Price": "",
        "Enabled": "",
        "Current Quantity": "20",
        "New Quantity": "19"
      }
    },
    {
      "id": 2,
      "datamaster": "Test Data",
      "userdata": {
        "Product": "Grape Jelly",
        "Description": "Gluten Free",
        "Category": "",
        "SKU": "5",
        "Price": "",
        "Enabled": "",
        "Current Quantity": "20",
        "New Quantity": "19"
      }
    },
    {
      "id": 3,
      "datamaster": "Test Data",
      "userdata": {
        "Product": "Blackberry Jam",
        "Description": "Berry Medley",
        "Category": "",
        "SKU": "6",
        "Price": "",
        "Enabled": "",
        "Current Quantity": "20",
        "New Quantity": "19"
      }
    },
    {
      "id": 4,
      "datamaster": "Test Data",
      "userdata": {
        "Product": "Strawberry Jam",
        "Description": "Strawberry",
        "Category": "",
        "SKU": "7",
        "Price": "",
        "Enabled": "",
        "Current Quantity": "19",
        "New Quantity": "18"
      }
    },
    {
      "id": 5,
      "datamaster": "Test Data",
      "userdata": {
        "Product": "Strawberry Jam",
        "Description": "Strawberry",
        "Category": "",
        "SKU": "8",
        "Price": "",
        "Enabled": "",
        "Current Quantity": "18",
        "New Quantity": "17"
      }
    }
  ];
  jimData.datamasters["Test Data"].category = {
    "Category": [""]
  };

  jimData.datamasters["JanuaryData"] = [
    {
      "id": 1,
      "datamaster": "JanuaryData",
      "userdata": {
        "Product": "Strawberry Jam",
        "Category": "Jam",
        "Price": "$8.00",
        "Date Sold": "01/12/2019",
        "Market": "Grant Park"
      }
    },
    {
      "id": 2,
      "datamaster": "JanuaryData",
      "userdata": {
        "Product": "Strawberry Jam",
        "Category": "Jam",
        "Price": "$8.00",
        "Date Sold": "01/12/2019",
        "Market": "Grant Park"
      }
    },
    {
      "id": 3,
      "datamaster": "JanuaryData",
      "userdata": {
        "Product": "Strawberry Jam",
        "Category": "Jam",
        "Price": "$8.00",
        "Date Sold": "01/12/2019",
        "Market": "Grant Park"
      }
    },
    {
      "id": 4,
      "datamaster": "JanuaryData",
      "userdata": {
        "Product": "Raspberry Jam",
        "Category": "Jam",
        "Price": "$8.00",
        "Date Sold": "01/12/2019",
        "Market": "Grant Park"
      }
    },
    {
      "id": 5,
      "datamaster": "JanuaryData",
      "userdata": {
        "Product": "Peanut Butter",
        "Category": "PB",
        "Price": "$7.00",
        "Date Sold": "01/12/2019",
        "Market": "Grant Park"
      }
    },
    {
      "id": 6,
      "datamaster": "JanuaryData",
      "userdata": {
        "Product": "Raspberry Jam",
        "Category": "Jam",
        "Price": "$8.00",
        "Date Sold": "01/12/2019",
        "Market": "Grant Park"
      }
    },
    {
      "id": 7,
      "datamaster": "JanuaryData",
      "userdata": {
        "Product": "Peanut Butter",
        "Category": "PB",
        "Price": "$7.00",
        "Date Sold": "01/12/2019",
        "Market": "Grant Park"
      }
    }
  ];
  jimData.datamasters["JanuaryData"].category = {
    "Market": ["Grant Park","Ponce City"]
  };

  jimData.datamasters["Test Data 2"] = [
    {
      "id": 1,
      "datamaster": "Test Data 2",
      "userdata": {
        "Product": "Strawberry Jam",
        "Cost": "$0.75",
        "Sales Price": "$3.75",
        "Units Sold": "47",
        "Net Sales": "$176.25",
        "Current Quantity": "20"
      }
    },
    {
      "id": 2,
      "datamaster": "Test Data 2",
      "userdata": {
        "Product": "Apple Butter",
        "Cost": "$0.34",
        "Sales Price": "$3.00",
        "Units Sold": "22",
        "Net Sales": "$66.00",
        "Current Quantity": "20"
      }
    },
    {
      "id": 3,
      "datamaster": "Test Data 2",
      "userdata": {
        "Product": "Raspberry Jam",
        "Cost": "$0.47",
        "Sales Price": "$3.00",
        "Units Sold": "10",
        "Net Sales": "$30.00",
        "Current Quantity": "20"
      }
    },
    {
      "id": 4,
      "datamaster": "Test Data 2",
      "userdata": {
        "Product": "Peanut Butter",
        "Cost": "$0.69",
        "Sales Price": "$3.75",
        "Units Sold": "5",
        "Net Sales": "$18.75",
        "Current Quantity": "19"
      }
    }
  ];

  jimData.isInitialized = true;
}