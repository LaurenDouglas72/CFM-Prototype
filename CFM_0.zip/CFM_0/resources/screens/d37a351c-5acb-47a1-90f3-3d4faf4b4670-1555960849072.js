jQuery("#simulation")
  .on("click", ".s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Home")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/d12245cc-1680-458d-89dd-4f0d7fb22724"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Data")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/84e35a6e-da09-48f6-a712-710e4b756e1f"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Analysis")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/d37a351c-5acb-47a1-90f3-3d4faf4b4670"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-foot_traffic_button")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimNotEquals",
                "parameter": [ {
                  "datatype": "variable",
                  "element": "footTrafficClicked"
                },"1" ]
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-foot_traffic_button > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#653308",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-foot_traffic_button": {
                      "attributes-ie": {
                        "-pie-background": "#653308",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-foot_traffic_button span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "variable": [ "footTrafficClicked" ],
                    "value": "1"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-strawberry_button")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimEquals",
                "parameter": [ {
                  "datatype": "variable",
                  "element": "footTrafficClicked"
                },"0" ]
              },
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "variable": [ "strawberryClicked" ],
                    "value": "1"
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "variable": [ "appleButterClicked" ],
                    "value": "0"
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "variable": [ "peanutButterClicked" ],
                    "value": "0"
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "variable": [ "raspberryClicked" ],
                    "value": "0"
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-strawberry_button > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#653308",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-strawberry_button span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-strawberry_button": {
                      "attributes-ie": {
                        "-pie-background": "#653308",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "variable": [ "overallClicked" ],
                    "value": "0"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-apple_butter_button")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimEquals",
                "parameter": [ {
                  "datatype": "variable",
                  "element": "footTrafficClicked"
                },"0" ]
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-apple_butter_button > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#653308",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-apple_butter_button span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-apple_butter_button": {
                      "attributes-ie": {
                        "-pie-background": "#653308",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "variable": [ "appleButterClicked" ],
                    "value": "1"
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "variable": [ "raspberryClicked","peanutButterClicked","strawberryClicked" ],
                    "value": "0"
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "variable": [ "overallClicked" ],
                    "value": "0"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-raspberry_button")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimEquals",
                "parameter": [ {
                  "datatype": "variable",
                  "element": "footTrafficClicked"
                },"0" ]
              },
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "variable": [ "raspberryClicked" ],
                    "value": "1"
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "variable": [ "appleButterClicked" ],
                    "value": "0"
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "variable": [ "peanutButterClicked" ],
                    "value": "0"
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "variable": [ "strawberryClicked" ],
                    "value": "0"
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-raspberry_button > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#653308",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-raspberry_button span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-raspberry_button": {
                      "attributes-ie": {
                        "-pie-background": "#653308",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "variable": [ "overallClicked" ],
                    "value": "0"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-peanut_butter_button")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimEquals",
                "parameter": [ {
                  "datatype": "variable",
                  "element": "footTrafficClicked"
                },"0" ]
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-peanut_butter_button > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#653308",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-peanut_butter_button span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-peanut_butter_button": {
                      "attributes-ie": {
                        "-pie-background": "#653308",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "variable": [ "peanutButterClicked" ],
                    "value": "1"
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "variable": [ "appleButterClicked","raspberryClicked","strawberryClicked" ],
                    "value": "0"
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "variable": [ "overallClicked" ],
                    "value": "0"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-day_button")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-day_button > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#653308",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-day_button span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-day_button": {
                      "attributes-ie": {
                        "-pie-background": "#653308",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "variable": [ "dayClicked" ],
                    "value": "1"
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "variable": [ "yearClicked","monthClicked","weatherCLicked","footTraffic2Clicked" ],
                    "value": "0"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-month_button")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-month_button > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#653308",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-month_button span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-month_button": {
                      "attributes-ie": {
                        "-pie-background": "#653308",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "variable": [ "monthClicked" ],
                    "value": "1"
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "variable": [ "yearClicked","weatherCLicked","footTraffic2Clicked","dayClicked" ],
                    "value": "0"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-year_button")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-year_button > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#653308",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-year_button span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-year_button": {
                      "attributes-ie": {
                        "-pie-background": "#653308",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "variable": [ "monthClicked","weatherCLicked","footTraffic2Clicked","dayClicked" ],
                    "value": "0"
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "variable": [ "yearClicked" ],
                    "value": "1"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-weather_button")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-weather_button > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#653308",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-weather_button span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-weather_button": {
                      "attributes-ie": {
                        "-pie-background": "#653308",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "variable": [ "weatherCLicked" ],
                    "value": "1"
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "variable": [ "yearClicked","monthClicked","footTraffic2Clicked","dayClicked" ],
                    "value": "0"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-sales_button_filled")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "variable": [ "footTrafficClicked" ],
                    "value": "0"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-foot_traffic_button_2")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimEquals",
                "parameter": [ {
                  "datatype": "variable",
                  "element": "footTrafficClicked"
                },"0" ]
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-foot_traffic_button_2 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#653308",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-foot_traffic_button_2 span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-foot_traffic_button_2": {
                      "attributes-ie": {
                        "-pie-background": "#653308",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "variable": [ "footTraffic2Clicked" ],
                    "value": "1"
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "variable": [ "yearClicked","monthClicked","weatherCLicked","dayClicked" ],
                    "value": "0"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-overall_button_filled")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "variable": [ "appleButterClicked" ],
                    "value": "0"
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "variable": [ "raspberryClicked" ],
                    "value": "0"
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "variable": [ "strawberryClicked" ],
                    "value": "0"
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "variable": [ "peanutButterClicked" ],
                    "value": "0"
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-overall_button_filled > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#653308",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-overall_button_filled span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-overall_button_filled": {
                      "attributes-ie": {
                        "-pie-background": "#653308",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "variable": [ "overallClicked" ],
                    "value": "1"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("pageload", ".s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 .pageload", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-strawberry_button")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-strawberry_button > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FFFFFF",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-strawberry_button span": {
                      "attributes": {
                        "color": "#653308"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-strawberry_button": {
                      "attributes-ie": {
                        "-pie-background": "#FFFFFF",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-year_button")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-year_button > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#653308",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-year_button span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-year_button": {
                      "attributes-ie": {
                        "-pie-background": "#653308",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "variable": [ "yearClicked" ],
                    "value": "1"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-sales_button_filled")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-sales_button_filled > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#653308",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-sales_button_filled": {
                      "attributes-ie": {
                        "-pie-background": "#653308",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-sales_button_filled span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-overall_button_filled")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-overall_button_filled > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#653308",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-overall_button_filled": {
                      "attributes-ie": {
                        "-pie-background": "#653308",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-overall_button_filled > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#653308",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-overall_button_filled span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-overall_button_filled": {
                      "attributes-ie": {
                        "-pie-background": "#653308",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "variable": [ "overallClicked" ],
                    "value": "1"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-sales_overall_Year")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-sales_overall_Year" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-sales_strawberry_year")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-sales_strawberry_year" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-sales_strawberry_month")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-sales_strawberry_month" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-sales_strawberry_foottraffic")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-sales_strawberry_foottraffic" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-foottraffic_overall_month")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-foottraffic_overall_month" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-foottraffic_overall_weather")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-foottraffic_overall_weather" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-sales_overall_weather")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-sales_overall_weather" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_2")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Image_2" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_3")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Image_3" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("variablechange.jim", ".s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 .variablechange", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-foot_traffic_button")) {
      cases = [
        {
          "blocks": [
            {
              "condition": (data.variableTarget === "footTrafficClicked") && {
                "action": "jimNotEquals",
                "parameter": [ {
                  "datatype": "variable",
                  "element": "footTrafficClicked"
                },"1" ]
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-foot_traffic_button > .backgroundLayer": {
                      "attributes": {
                        "background-color": "transparent",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-foot_traffic_button": {
                      "attributes-ie": {
                        "-pie-background": "transparent",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-foot_traffic_button span": {
                      "attributes": {
                        "color": "#653308"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-strawberry_button")) {
      cases = [
        {
          "blocks": [
            {
              "condition": (data.variableTarget === "strawberryClicked") && {
                "action": "jimEquals",
                "parameter": [ {
                  "datatype": "variable",
                  "element": "strawberryClicked"
                },"0" ]
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-strawberry_button > .backgroundLayer": {
                      "attributes": {
                        "background-color": "transparent",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-strawberry_button span": {
                      "attributes": {
                        "color": "#653308"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-strawberry_button": {
                      "attributes-ie": {
                        "-pie-background": "transparent",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "condition": (data.variableTarget === "footTrafficClicked") && {
                "action": "jimEquals",
                "parameter": [ {
                  "datatype": "variable",
                  "element": "footTrafficClicked"
                },"1" ]
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-strawberry_button span": {
                      "attributes": {
                        "color": "#999999"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "condition": (data.variableTarget === "footTrafficClicked"),
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-strawberry_button span": {
                      "attributes": {
                        "color": "#653308"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-apple_butter_button")) {
      cases = [
        {
          "blocks": [
            {
              "condition": (data.variableTarget === "appleButterClicked") && {
                "action": "jimEquals",
                "parameter": [ {
                  "datatype": "variable",
                  "element": "appleButterClicked"
                },"0" ]
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-apple_butter_button > .backgroundLayer": {
                      "attributes": {
                        "background-color": "transparent",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-apple_butter_button span": {
                      "attributes": {
                        "color": "#653308"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-apple_butter_button": {
                      "attributes-ie": {
                        "-pie-background": "transparent",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "condition": (data.variableTarget === "footTrafficClicked") && {
                "action": "jimEquals",
                "parameter": [ {
                  "datatype": "variable",
                  "element": "footTrafficClicked"
                },"1" ]
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-apple_butter_button span": {
                      "attributes": {
                        "color": "#999999"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "condition": (data.variableTarget === "footTrafficClicked"),
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-apple_butter_button span": {
                      "attributes": {
                        "color": "#653308"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-raspberry_button")) {
      cases = [
        {
          "blocks": [
            {
              "condition": (data.variableTarget === "raspberryClicked") && {
                "action": "jimEquals",
                "parameter": [ {
                  "datatype": "variable",
                  "element": "raspberryClicked"
                },"0" ]
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-raspberry_button > .backgroundLayer": {
                      "attributes": {
                        "background-color": "transparent",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-raspberry_button span": {
                      "attributes": {
                        "color": "#653308"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-raspberry_button": {
                      "attributes-ie": {
                        "-pie-background": "transparent",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "condition": (data.variableTarget === "footTrafficClicked") && {
                "action": "jimEquals",
                "parameter": [ {
                  "datatype": "variable",
                  "element": "footTrafficClicked"
                },"1" ]
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-raspberry_button span": {
                      "attributes": {
                        "color": "#999999"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "condition": (data.variableTarget === "footTrafficClicked"),
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-raspberry_button span": {
                      "attributes": {
                        "color": "#653308"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-peanut_butter_button")) {
      cases = [
        {
          "blocks": [
            {
              "condition": (data.variableTarget === "peanutButterClicked") && {
                "action": "jimEquals",
                "parameter": [ {
                  "datatype": "variable",
                  "element": "peanutButterClicked"
                },"0" ]
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-peanut_butter_button > .backgroundLayer": {
                      "attributes": {
                        "background-color": "transparent",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-peanut_butter_button span": {
                      "attributes": {
                        "color": "#653308"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-peanut_butter_button": {
                      "attributes-ie": {
                        "-pie-background": "transparent",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "condition": (data.variableTarget === "footTrafficClicked") && {
                "action": "jimEquals",
                "parameter": [ {
                  "datatype": "variable",
                  "element": "footTrafficClicked"
                },"1" ]
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-peanut_butter_button span": {
                      "attributes": {
                        "color": "#999999"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "condition": (data.variableTarget === "footTrafficClicked"),
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-peanut_butter_button span": {
                      "attributes": {
                        "color": "#653308"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-day_button")) {
      cases = [
        {
          "blocks": [
            {
              "condition": (data.variableTarget === "dayClicked") && {
                "action": "jimEquals",
                "parameter": [ {
                  "datatype": "variable",
                  "element": "dayClicked"
                },"0" ]
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-day_button > .backgroundLayer": {
                      "attributes": {
                        "background-color": "transparent",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-day_button span": {
                      "attributes": {
                        "color": "#653308"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-day_button": {
                      "attributes-ie": {
                        "-pie-background": "transparent",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-month_button")) {
      cases = [
        {
          "blocks": [
            {
              "condition": (data.variableTarget === "monthClicked") && {
                "action": "jimEquals",
                "parameter": [ {
                  "datatype": "variable",
                  "element": "monthClicked"
                },"0" ]
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-month_button > .backgroundLayer": {
                      "attributes": {
                        "background-color": "transparent",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-month_button span": {
                      "attributes": {
                        "color": "#653308"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-month_button": {
                      "attributes-ie": {
                        "-pie-background": "transparent",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-year_button")) {
      cases = [
        {
          "blocks": [
            {
              "condition": (data.variableTarget === "yearClicked") && {
                "action": "jimEquals",
                "parameter": [ {
                  "datatype": "variable",
                  "element": "yearClicked"
                },"0" ]
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-year_button > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FFFFFF",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-year_button span": {
                      "attributes": {
                        "color": "#653308"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-year_button": {
                      "attributes-ie": {
                        "-pie-background": "#FFFFFF",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-weather_button")) {
      cases = [
        {
          "blocks": [
            {
              "condition": (data.variableTarget === "weatherCLicked") && {
                "action": "jimEquals",
                "parameter": [ {
                  "datatype": "variable",
                  "element": "weatherCLicked"
                },"0" ]
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-weather_button > .backgroundLayer": {
                      "attributes": {
                        "background-color": "transparent",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-weather_button span": {
                      "attributes": {
                        "color": "#653308"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-weather_button": {
                      "attributes-ie": {
                        "-pie-background": "transparent",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-sales_button_filled")) {
      cases = [
        {
          "blocks": [
            {
              "condition": (data.variableTarget === "footTrafficClicked") && {
                "action": "jimNotEquals",
                "parameter": [ {
                  "datatype": "variable",
                  "element": "footTrafficClicked"
                },"0" ]
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-sales_button_filled > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FFFFFF",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-sales_button_filled": {
                      "attributes-ie": {
                        "-pie-background": "#FFFFFF",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-sales_button_filled span": {
                      "attributes": {
                        "color": "#653308"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "condition": (data.variableTarget === "footTrafficClicked"),
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-sales_button_filled > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#653308",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-sales_button_filled": {
                      "attributes-ie": {
                        "-pie-background": "#653308",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-sales_button_filled span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-foot_traffic_button_2")) {
      cases = [
        {
          "blocks": [
            {
              "condition": (data.variableTarget === "footTraffic2Clicked") && {
                "action": "jimEquals",
                "parameter": [ {
                  "datatype": "variable",
                  "element": "footTraffic2Clicked"
                },"0" ]
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-foot_traffic_button_2 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "transparent",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-foot_traffic_button_2 span": {
                      "attributes": {
                        "color": "#653308"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-foot_traffic_button_2": {
                      "attributes-ie": {
                        "-pie-background": "transparent",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "condition": (data.variableTarget === "footTrafficClicked") && {
                "action": "jimEquals",
                "parameter": [ {
                  "datatype": "variable",
                  "element": "footTrafficClicked"
                },"1" ]
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-foot_traffic_button_2 span": {
                      "attributes": {
                        "color": "#999999"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "condition": (data.variableTarget === "footTrafficClicked"),
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-foot_traffic_button_2 span": {
                      "attributes": {
                        "color": "#653308"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-overall_button_filled")) {
      cases = [
        {
          "blocks": [
            {
              "condition": (data.variableTarget === "raspberryClicked") && {
                "action": "jimNotEquals",
                "parameter": [ {
                  "datatype": "variable",
                  "element": "raspberryClicked"
                },"0" ]
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-overall_button_filled > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FFFFFF",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-overall_button_filled span": {
                      "attributes": {
                        "color": "#653308"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-overall_button_filled": {
                      "attributes-ie": {
                        "-pie-background": "#FFFFFF",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "condition": (data.variableTarget === "strawberryClicked") && {
                "action": "jimNotEquals",
                "parameter": [ {
                  "datatype": "variable",
                  "element": "strawberryClicked"
                },"0" ]
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-overall_button_filled > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FFFFFF",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-overall_button_filled span": {
                      "attributes": {
                        "color": "#653308"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-overall_button_filled": {
                      "attributes-ie": {
                        "-pie-background": "#FFFFFF",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "condition": (data.variableTarget === "appleButterClicked") && {
                "action": "jimNotEquals",
                "parameter": [ {
                  "datatype": "variable",
                  "element": "appleButterClicked"
                },"0" ]
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-overall_button_filled > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FFFFFF",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-overall_button_filled span": {
                      "attributes": {
                        "color": "#653308"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-overall_button_filled": {
                      "attributes-ie": {
                        "-pie-background": "#FFFFFF",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "condition": (data.variableTarget === "peanutButterClicked") && {
                "action": "jimNotEquals",
                "parameter": [ {
                  "datatype": "variable",
                  "element": "peanutButterClicked"
                },"0" ]
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-overall_button_filled > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FFFFFF",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-overall_button_filled span": {
                      "attributes": {
                        "color": "#653308"
                      }
                    }
                  },{
                    "#s-d37a351c-5acb-47a1-90f3-3d4faf4b4670 #s-overall_button_filled": {
                      "attributes-ie": {
                        "-pie-background": "#FFFFFF",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-sales_overall_Year")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimAnd",
                "parameter": [ {
                  "action": "jimAnd",
                  "parameter": [ {
                    "action": "jimEquals",
                    "parameter": [ {
                      "datatype": "variable",
                      "element": "overallClicked"
                    },"1" ]
                  },{
                    "action": "jimEquals",
                    "parameter": [ {
                      "datatype": "variable",
                      "element": "footTrafficClicked"
                    },"0" ]
                  } ]
                },{
                  "action": "jimEquals",
                  "parameter": [ {
                    "datatype": "variable",
                    "element": "yearClicked"
                  },"1" ]
                } ]
              },
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-sales_overall_Year" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-sales_overall_Year" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-sales_strawberry_year")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimAnd",
                "parameter": [ {
                  "action": "jimAnd",
                  "parameter": [ {
                    "action": "jimEquals",
                    "parameter": [ {
                      "datatype": "variable",
                      "element": "footTrafficClicked"
                    },"0" ]
                  },{
                    "action": "jimEquals",
                    "parameter": [ {
                      "datatype": "variable",
                      "element": "strawberryClicked"
                    },"1" ]
                  } ]
                },{
                  "action": "jimEquals",
                  "parameter": [ {
                    "datatype": "variable",
                    "element": "yearClicked"
                  },"1" ]
                } ]
              },
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-sales_strawberry_year" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-sales_strawberry_year" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-sales_strawberry_month")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimAnd",
                "parameter": [ {
                  "action": "jimAnd",
                  "parameter": [ {
                    "action": "jimEquals",
                    "parameter": [ {
                      "datatype": "variable",
                      "element": "strawberryClicked"
                    },"1" ]
                  },{
                    "action": "jimEquals",
                    "parameter": [ {
                      "datatype": "variable",
                      "element": "monthClicked"
                    },"1" ]
                  } ]
                },{
                  "action": "jimEquals",
                  "parameter": [ {
                    "datatype": "variable",
                    "element": "footTrafficClicked"
                  },"0" ]
                } ]
              },
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-sales_strawberry_month" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-sales_strawberry_month" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-sales_strawberry_foottraffic")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimAnd",
                "parameter": [ {
                  "action": "jimAnd",
                  "parameter": [ {
                    "action": "jimEquals",
                    "parameter": [ {
                      "datatype": "variable",
                      "element": "footTrafficClicked"
                    },"0" ]
                  },{
                    "action": "jimEquals",
                    "parameter": [ {
                      "datatype": "variable",
                      "element": "strawberryClicked"
                    },"1" ]
                  } ]
                },{
                  "action": "jimEquals",
                  "parameter": [ {
                    "datatype": "variable",
                    "element": "footTraffic2Clicked"
                  },"1" ]
                } ]
              },
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-sales_strawberry_foottraffic" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-sales_strawberry_foottraffic" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-foottraffic_overall_month")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimAnd",
                "parameter": [ {
                  "action": "jimEquals",
                  "parameter": [ {
                    "datatype": "variable",
                    "element": "footTrafficClicked"
                  },"1" ]
                },{
                  "action": "jimEquals",
                  "parameter": [ {
                    "datatype": "variable",
                    "element": "monthClicked"
                  },"1" ]
                } ]
              },
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-foottraffic_overall_month" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-foottraffic_overall_month" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-foottraffic_overall_weather")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimAnd",
                "parameter": [ {
                  "action": "jimEquals",
                  "parameter": [ {
                    "datatype": "variable",
                    "element": "footTrafficClicked"
                  },"1" ]
                },{
                  "action": "jimEquals",
                  "parameter": [ {
                    "datatype": "variable",
                    "element": "weatherCLicked"
                  },"1" ]
                } ]
              },
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-foottraffic_overall_weather" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-foottraffic_overall_weather" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-sales_overall_weather")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimAnd",
                "parameter": [ {
                  "action": "jimAnd",
                  "parameter": [ {
                    "action": "jimEquals",
                    "parameter": [ {
                      "datatype": "variable",
                      "element": "footTrafficClicked"
                    },"0" ]
                  },{
                    "action": "jimEquals",
                    "parameter": [ {
                      "datatype": "variable",
                      "element": "overallClicked"
                    },"1" ]
                  } ]
                },{
                  "action": "jimEquals",
                  "parameter": [ {
                    "datatype": "variable",
                    "element": "weatherCLicked"
                  },"1" ]
                } ]
              },
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-sales_overall_weather" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-sales_overall_weather" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_2")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimAnd",
                "parameter": [ {
                  "action": "jimEquals",
                  "parameter": [ {
                    "datatype": "variable",
                    "element": "footTrafficClicked"
                  },"1" ]
                },{
                  "action": "jimEquals",
                  "parameter": [ {
                    "datatype": "variable",
                    "element": "yearClicked"
                  },"1" ]
                } ]
              },
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Image_2" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Image_2" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_3")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimAnd",
                "parameter": [ {
                  "action": "jimEquals",
                  "parameter": [ {
                    "datatype": "variable",
                    "element": "footTrafficClicked"
                  },"0" ]
                },{
                  "action": "jimAnd",
                  "parameter": [ {
                    "action": "jimEquals",
                    "parameter": [ {
                      "datatype": "variable",
                      "element": "overallClicked"
                    },"1" ]
                  },{
                    "action": "jimEquals",
                    "parameter": [ {
                      "datatype": "variable",
                      "element": "footTraffic2Clicked"
                    },"1" ]
                  } ]
                } ]
              },
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Image_3" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Image_3" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  });