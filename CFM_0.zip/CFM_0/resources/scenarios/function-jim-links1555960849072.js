(function(window, undefined) {

  var jimLinks = {
    "72a32d11-52db-47b6-ac75-289b3920287b" : {
      "Button_2" : [
        "84e35a6e-da09-48f6-a712-710e4b756e1f"
      ],
      "Button_3" : [
        "84e35a6e-da09-48f6-a712-710e4b756e1f"
      ],
      "Home" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Data" : [
        "84e35a6e-da09-48f6-a712-710e4b756e1f"
      ],
      "Analysis" : [
        "d37a351c-5acb-47a1-90f3-3d4faf4b4670"
      ]
    },
    "34d6aefd-e1f9-4c91-a7d3-34956aa71d97" : {
      "Home" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Data" : [
        "84e35a6e-da09-48f6-a712-710e4b756e1f"
      ],
      "Analysis" : [
        "d37a351c-5acb-47a1-90f3-3d4faf4b4670"
      ],
      "Events" : [
        "34d6aefd-e1f9-4c91-a7d3-34956aa71d97"
      ]
    },
    "84e35a6e-da09-48f6-a712-710e4b756e1f" : {
      "Home" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Data" : [
        "84e35a6e-da09-48f6-a712-710e4b756e1f"
      ],
      "Analysis" : [
        "d37a351c-5acb-47a1-90f3-3d4faf4b4670"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Home" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Data" : [
        "84e35a6e-da09-48f6-a712-710e4b756e1f"
      ],
      "Analysis" : [
        "d37a351c-5acb-47a1-90f3-3d4faf4b4670"
      ]
    },
    "d37a351c-5acb-47a1-90f3-3d4faf4b4670" : {
      "Home" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Data" : [
        "84e35a6e-da09-48f6-a712-710e4b756e1f"
      ],
      "Analysis" : [
        "d37a351c-5acb-47a1-90f3-3d4faf4b4670"
      ]
    },
    "580005d5-0876-4654-89c6-e2e2adc958c1" : {
    }    
  }

  window.jimLinks = jimLinks;
})(window);